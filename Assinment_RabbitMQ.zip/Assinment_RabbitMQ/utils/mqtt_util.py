import json
from datetime import datetime
from constants import app_constants
from constants import app_configurations
import paho.mqtt.client as mqtt
from utils.mongo_utility import MongoConnect


class MqttUtility:
    def __init__(self):
        try:
            broker_address = app_configurations.BROKER_ADDRESS
            broker_port = app_configurations.BROKER_PORT
            self.client = mqtt.Client()
            self.client.connect(broker_address, broker_port)
            self.client.on_connect = self.print_connection_status
            self.mongo_client = MongoConnect()


        except Exception as e:
            print(f"connection failed to mqtt ::{e}")

    def print_connection_status(self, client, userdata, flags, rc):
        if rc == 0:
            print("connected OK Returned code=", rc)
        else:
            print("Bad connection Returned code=", rc)

    def process_message(self, message):
        # Extract status from message
        status = message["status"]
        # Insert message data with timestamp
        json_data = {"status": status, "timestamp": datetime.utcnow()}
        self.mongo_client.insert_one(json_data, app_configurations.DB, app_constants.MongoInfo.COLLECTION)

    def on_message(self, client, userdata, msg):
        # Decode and process received message
        message = json.loads(msg.payload.decode())
        self.process_message(message)