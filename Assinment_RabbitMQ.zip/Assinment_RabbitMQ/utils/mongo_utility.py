""" Mongo DB utility
All definitions related to mongo db is defined in this module
"""
from pymongo import MongoClient
from pymongo.errors import BulkWriteError, ConnectionFailure
from pymongo.errors import DuplicateKeyError as MongoDuplicateKeyError

from constants import app_configurations, app_constants
from constants.app_constants import MongoEncryptionConstants
from constants.db_connection_obj import ConnectionObj
from exceptions import exception_codes, module_exceptions

class MongoConnect():
    def __init__(self):
        try:
            self.__mongo_OBJ__ = MongoClient(app_configurations.MONGO_URI)
            try:
                self.__mongo_OBJ__.admin.command("ismaster")
            except ConnectionFailure:
                raise module_exceptions.MongoConnectionException(
                    "Unable to create a connection with the metastore"
                )
            print("Mongo connection established")

        except Exception as e:
            ConnectionObj.mongo_connection_obj = None
            print("Error in establishing connection: " + str(e))
            raise module_exceptions.MongoConnectionException(MongoEncryptionConstants.MONGO001)

    def __del__(self):
        """
        To close the mongo connection
        :return:
        """
        try:
            if self.__mongo_OBJ__ is not None:
                self.__mongo_OBJ__.close()
            print("Mongo connection closed")
        except Exception as e:
            print("Error during closing of connection: " + str(e))
            raise module_exceptions.MongoConnectionException(exception_codes.MONGO007)

    def get_mongo_obj(self):
        return self.__mongo_OBJ__

    def insert_one(self, json_data, database_name, collection_name):
        """
        To insert single document in collection
        :param json_data: The document data to be inserted.
        :param database_name: The database to which the collection/ document belongs to.
        :param collection_name: The collection to which the document belongs to.
        :return: id
        """
        try:
            mongo_response = self.__mongo_OBJ__[database_name][collection_name].insert_one(json_data)
            print("Inserted document in mongo")
            return mongo_response.inserted_id
        except module_exceptions.MongoException as e:
            raise module_exceptions.MongoException(e)
        except MongoDuplicateKeyError:
            raise MongoDuplicateKeyError("Found an existing record with the same ID in MongoDB")
        except Exception as e:
            print(f"{exception_codes.MONGO002}: {str(e)}")
            raise module_exceptions.MongoRecordInsertionException(f"{exception_codes.MONGO002}: {str(e)}")

    def aggregate_query(self, json_data, database_name, collection_name):
        """
        To search using aggregate query
        :param json_data:
        :param database_name: The database to which the collection/documents belongs to.
        :param collection_name: The collection to which the documents belongs to.
        :return: response object
        """
        try:
            database_connection = self.__mongo_OBJ__[database_name]
            mongo_response = database_connection[collection_name].aggregate(json_data)
            print("Fetched results from mongo")
            return mongo_response
        except Exception as e:
            print(f"{exception_codes.MONGO006}: {str(e)}")
            raise module_exceptions.MongoQueryException(f"{exception_codes.MONGO006}: {str(e)}")

    def aggregate(self, db_name, collection_name, list_for_aggregation):
        """

        :param db_name:
        :param collection_name:
        :param list_for_aggregation:
        :return:
        """
        mg_response = {}
        try:
            docid = self.__mongo_OBJ__[db_name][collection_name]
            mg_response = docid.aggregate(list_for_aggregation)
        except Exception as e:
            print(f"{exception_codes.MONGO006}: {str(e)}")
        return mg_response

    def close_connection(self):
        """
        To close the mongo connection
        :return:
        """
        try:
            if self.__mongo_OBJ__ is not None:
                self.__mongo_OBJ__.close()
            print("Mongo connection closed")
        except Exception as e:
            print(f"{exception_codes.MONGO007}: {str(e)}")
            raise module_exceptions.MongoConnectionException(f"{exception_codes.MONGO007}: {str(e)}")

