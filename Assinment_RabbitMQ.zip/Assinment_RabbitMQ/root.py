import multiprocessing

import uvicorn
from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

from constants.app_configurations import FAST_SERVICE_PORT, SERVICE_HOST
from core.managers.data_source_manager import DocumentProcessor
from core import router


class FastAPIServices:
    @staticmethod
    def fast_api():
        app = FastAPI()
        app.include_router(router)

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["GET", "POST", "DELETE", "PUT"],
            allow_headers=["*"],
        )

        try:
            uvicorn.run(app, host=SERVICE_HOST, port=int(FAST_SERVICE_PORT))

        except Exception as e:
            print(f"Unable to launch FAST API: {str(e)}")


# class GradioAPIServices:
#     @staticmethod
#     def gardio_api():
#         GradioUi().gradio_ui()


if __name__ == "__main__":
    # logger.info('Gradio services are running..')
    # p1 = multiprocessing.Process(target=GradioAPIServices().gardio_api)
    # p1.start()

    print("FAST API services are running..")
    p1 = multiprocessing.Process(target=FastAPIServices().fast_api)
    p1.start()

    try:
        doc_proc = DocumentProcessor()
        doc_proc.run_process_thread()
        print("Process thread is getting initialized...")

    except Exception as e:
        print(f"Failed to files indexing::{str(e)}")
