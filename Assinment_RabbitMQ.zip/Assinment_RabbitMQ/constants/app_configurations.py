import os
import sys
from configparser import BasicInterpolation, ConfigParser

from dotenv import load_dotenv

# Configuration File Constants
_application_conf = "./conf/application.conf"
_default_conf = "./dev-variables.env"
# _default_conf = "./config.env"

load_dotenv(dotenv_path=_default_conf)


class EnvInterpolation(BasicInterpolation):
    """
    Interpolation which expands environment variables in values.
    """

    def before_get(self, parser, section, option, value, defaults):
        value = super().before_get(parser, section, option, value, defaults)

        if not os.path.expandvars(value).startswith("$"):
            return os.path.expandvars(value)
        else:
            return


try:
    config = ConfigParser(interpolation=EnvInterpolation())
    config.read(_application_conf)
except Exception as e:
    print(f"Error while loading the config: {e}")
    print("Failed to Load Configuration. Exiting!!!")
    sys.exit()

# configuration variables

# MONGO METADATA
MONGO_URI = config.get("MONGODB", "MONGO_URI")
DB = config.get("MONGODB", "DB")

# API
SERVICE_HOST = config.get("API", "SERVICE_HOST")
FAST_SERVICE_PORT = config.getint("API", "FAST_SERVICE_PORT")

#MQTT
BROKER_ADDRESS = config.get("MQTT", "BROKER_ADDRESS")
BROKER_PORT = config.get("MQTT", "BROKER_PORT")