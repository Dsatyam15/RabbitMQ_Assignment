class ConnectionObj:
    def __init__(self):
        self.mongo_connection_obj = None


ConnectionObj = ConnectionObj()
