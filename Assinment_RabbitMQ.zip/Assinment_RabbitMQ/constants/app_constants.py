class Routes:
    mqtt = "/app/mqtt"
class NameSpaces:
    mqtt = "mqtt"

class FileProperties:
    INPROGRESS = "inprogress"
    FAILED = "failed"
    SUCCESS = "success"
class Apps:
    publish_message = "/publish/message"
    get_status = "/get/status/count"

class SatusCodes:
    inprogress = 0
    success = 1
    failed = 2
    duplicated = 4
    deleted = 3

class MongoInfo:
    COLLECTION = "some_collection"

class MqttInfo:
    TOPIC = "some_topic"



