Use python 3.9 or above

Do pip install -r requirements.txt

Change the variables like mqtt broker address port, mongo connection URI etc in dev variables

Change the collection name and topic name in app_constants in constants

run root.py

Trigger the /publish/message API to start publishing messages to MQTT

Give start_time and end_time as params in the format: YYYY-MM-DDTHH:mm:ss to the /get/status/count API

Utils have basic mongo and mqtt utility functions

API server level code is present in core/services/mqtt_services.py

API handler/client level code is present in core/handlers/mqtt_handler.py

Schema for the API is present in core/schemas/genai_schemas.py


