from fastapi import APIRouter

from .services.mqtt_services import router_mqtt


router = APIRouter()
router.include_router(router_mqtt)
