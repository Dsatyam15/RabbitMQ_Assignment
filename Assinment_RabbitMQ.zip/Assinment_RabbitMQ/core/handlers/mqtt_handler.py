import json
from datetime import datetime
import random
import time
import threading
from constants import app_configurations, app_constants
from utils.mongo_utility import MongoConnect
from utils.mqtt_util import MqttUtility

class MQTT:
    def __init__(self, topic):
        self.mon_conn = MongoConnect()
        self.mqtt_client = MqttUtility().client
        self.mqtt_client.on_message = MqttUtility().on_message
        self.mqtt_client.subscribe(topic)
        self.mqtt_client.loop_start()

    def publish_to_mqtt(self):
        try:
            thread = threading.Thread(target=self.mqtt_publish, args=(app_constants.MqttInfo.TOPIC,))
            thread.start()
            return []
        except Exception as ex:
            print(f"Cannot publish to MQTT topic: {app_constants.MqttInfo.TOPIC}")

    def mqtt_publish(self, topic):
        try:
            while True:
                # Generate random status between 0 and 6
                status = random.randint(0, 6)
                message = {"status": status}

                # Publish message to the topic
                self.mqtt_client.publish(topic, json.dumps(message))
                print(f"Message published to topic :{topic}: {message}")

                time.sleep(1)
        except Exception as ex:
            print(f"Failed to publish message to the topic {topic}")

    def fetch_status_count(self, req_json):
        try:
            start_time = datetime.fromisoformat(req_json.start_time)
            end_time = datetime.fromisoformat(req_json.end_time)
            list_for_aggregation = [
      {
          "$match": {
              "timestamp": {"$gte": start_time, "$lt": end_time}
          }
      },
      {
          "$group": {
              "_id": "$status",
              "count": {"$sum": 1}
          }
      }
  ]
            response = self.mon_conn.aggregate(app_configurations.DB, app_constants.MongoInfo.COLLECTION, list_for_aggregation)
            result = list(response)
            return result
        except Exception as ex:
            print(f"Failed to fetch records: {ex}")

