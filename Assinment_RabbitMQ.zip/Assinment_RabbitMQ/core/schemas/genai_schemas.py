from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel



class MqttData(BaseModel):
    start_time: str
    end_time: str
class StatusCountResponse(BaseModel):
    status: str
    message: str
    data: Optional[list]

