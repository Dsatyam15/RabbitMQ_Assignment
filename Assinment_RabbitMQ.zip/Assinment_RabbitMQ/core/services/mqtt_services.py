from fastapi import APIRouter, FastAPI
from constants import app_constants
from core.handlers.mqtt_handler import MQTT
from core.schemas import genai_schemas

app = FastAPI()
router_mqtt = APIRouter(prefix=app_constants.Routes.mqtt, tags=[app_constants.NameSpaces.mqtt])


@router_mqtt.get(
    path=app_constants.Apps.publish_message,
    tags=[app_constants.NameSpaces.mqtt],
)
async def publish_message():
    try:
        response = MQTT(app_constants.MqttInfo.TOPIC).publish_to_mqtt()
        return genai_schemas.StatusCountResponse(
            status=app_constants.FileProperties.SUCCESS,
            message="Started publishing to MQTT",
            data=response,
        )

    except Exception as e:
        print(f"Unable to start publishing to MQTT {str(e)}")
        return genai_schemas.StatusCountResponse(status=app_constants.FileProperties.FAILED, message=str(e))

@router_mqtt.post(
    path=app_constants.Apps.get_status,
    tags=[app_constants.NameSpaces.mqtt],
)
async def list_status_count(req_json: genai_schemas.MqttData):
    try:
        response = MQTT(app_constants.MqttInfo.TOPIC).fetch_status_count(req_json)
        return genai_schemas.StatusCountResponse(
            status=app_constants.FileProperties.SUCCESS,
            message="Successfully Fetched status counts",
            data=response,
        )

    except Exception as e:
        print(f"Unable to fetch status counts {str(e)}")
        return genai_schemas.StatusCountResponse(status=app_constants.FileProperties.FAILED, message=str(e))